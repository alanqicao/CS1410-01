/**
 * 
 */
package phones;

/**
 * @author caose_000
 *
 */
public enum Voltage {
	V110, V220, DUAL
}
