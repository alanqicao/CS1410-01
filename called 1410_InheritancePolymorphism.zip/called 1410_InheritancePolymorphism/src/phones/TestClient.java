/**
 * 
 */
package phones;

/**
 * @author caose_000
 *
 */
public class TestClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dimension dm = new Dimension(140,208,119);
		SmartPhone sp = new SmartPhone("Cortelco 2500 ",dm,128);
		
		System.out.println(sp.takePicture());
	}

}
