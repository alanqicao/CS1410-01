/**
 * 
 */
package nuisance;

/**
 * @author caose_000
 *
 */
public class Friend extends Person {
	
	private Hobby hobby;
	/**
	 * @param name
	 * @param age
	 */
	public Friend(String name, int age, Hobby hobby) {
		super(name, age);
		this.hobby = hobby;
		// TODO Auto-generated constructor stub
	}
	
	public String chill() {
		
		return super.getName()+" is chilling";
	}
	
	public String play(Friend[] friends) {
		String sn = "Playing "+hobby+" with ";
//		switch(friends.length) {
//		case 0:
//			return "Playing"+hobby;
//			break;
//		}
		if(friends.length>0) {
			sn+=friends[0].getName();
			for(int i=1; i<friends.length-1; i++) {
				
				sn+=", "+friends[i].getName();
				
			}
			
			sn+=", and "+friends[friends.length-1].getName()+".";
		}
		
		
	
		return sn;
	}

	@Override
	public String toString() {
		return "Friend [hobby=" + hobby + "]";
	}
	

}
