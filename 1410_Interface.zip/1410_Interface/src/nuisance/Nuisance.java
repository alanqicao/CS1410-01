/**
 * 
 */
package nuisance;

/**
 * @author caose_000
 *
 */
public interface Nuisance {
	String annoy();
}
