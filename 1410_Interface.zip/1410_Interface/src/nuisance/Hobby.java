/**
 * 
 */
package nuisance;

/**
 * @author caose_000
 *
 */
public enum Hobby {
	MUSIC, SPORTS, GAMES
}
