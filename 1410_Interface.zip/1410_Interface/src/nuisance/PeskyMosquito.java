/**
 * 
 */
package nuisance;

/**
 * @author caose_000
 *
 */
public class PeskyMosquito extends Mosquito {

	/**
	 * @param species
	 */
	public PeskyMosquito(String species) {
		super(species);
		// TODO Auto-generated constructor stub
	}
	
	public String bite() {
		return null;
	}

}
