/**
 * 
 */
package nuisance;

import java.util.List;

/**
 * @author caose_000
 *
 */
public class Butterfly extends Insect {
	private List<String> colors;
	/**
	 * @param species
	 */
	public Butterfly(String species, List<String> colors) {
		super(species);
		this.colors = colors;
	}
	
	public Butterfly(Butterfly butterfly) {
		
		new Butterfly(butterfly.getSpecies(), this.getColors());
	}

	/**
	 * @return the colors
	 */
	public List<String> getColors() {
		return colors;
	}

	@Override
	public String toString() {
		return "Butterfly [colors=" + colors + "]";
	}
	
	
	
}
